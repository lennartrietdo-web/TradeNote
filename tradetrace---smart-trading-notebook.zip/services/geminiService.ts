
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Create a new instance right before the call as recommended to ensure latest configuration.
export const analyzeTradeImage = async (base64Image: string, notes: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    You are a professional trading mentor. Analyze the provided trade screenshot and the trader's notes: "${notes}".
    
    Tasks:
    1. Identify technical patterns visible in the chart (e.g., support/resistance, breakouts, indicators).
    2. Provide a constructive review of the trade setup.
    3. Suggest one improvement for the future.
    
    Keep the response concise and insightful. Use bullet points.
  `;

  try {
    // Using gemini-3-pro-preview for advanced multimodal analysis of trading charts.
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [{
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image.split(',')[1] || base64Image
            }
          }
        ]
      }]
    });

    // Access the text property directly without calling it as a function.
    return response.text || "Could not analyze the image at this time.";
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return "Analysis failed. Please check your API configuration.";
  }
};
