
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  format, 
  addMonths, 
  subMonths, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  isSameMonth, 
  isSameDay, 
  addDays, 
  parseISO 
} from 'date-fns';
import { 
  Plus, 
  ChevronLeft, 
  ChevronRight, 
  TrendingUp, 
  TrendingDown, 
  Image as ImageIcon, 
  Trash2, 
  Pencil,
  BrainCircuit, 
  BarChart3, 
  Calendar as CalendarIcon,
  Maximize2,
  X,
  Target,
  Zap,
  ShieldAlert,
  Wallet,
  LayoutDashboard,
  ArrowUpRight,
  ArrowDownRight,
  History,
  Coins,
  ChevronDown,
  User as UserIcon,
  LogOut,
  Lock,
  Mail,
  UserPlus,
  CreditCard,
  PieChart as PieChartIcon,
  Settings,
  Bell,
  Eye,
  EyeOff
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Trade, TradeType, DailySummary, User } from './types';
import { analyzeTradeImage } from './services/geminiService';

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

const CURRENCIES = {
  USD: { symbol: '$', rate: 1, label: 'US Dollar' },
  EUR: { symbol: '€', rate: 0.92, label: 'Euro' },
  GBP: { symbol: '£', rate: 0.79, label: 'British Pound' },
  JPY: { symbol: '¥', rate: 151.4, label: 'Japanese Yen' },
  BTC: { symbol: '₿', rate: 0.000015, label: 'Bitcoin' }
};

type CurrencyCode = keyof typeof CURRENCIES;

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('trade_trace_session');
    return saved ? JSON.parse(saved) : null;
  });
  const [isAuthMode, setIsAuthMode] = useState<'login' | 'register'>('login');
  const [activeTab, setActiveTab] = useState<'journal' | 'portfolio'>('journal');
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>('USD');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [trades, setTrades] = useState<Trade[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [editingTradeId, setEditingTradeId] = useState<string | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  // Auth Form State
  const [authForm, setAuthForm] = useState({ email: '', password: '', name: '' });
  
  // Trade Form State
  const [formData, setFormData] = useState({
    symbol: '',
    type: TradeType.LONG,
    entryPrice: '',
    exitPrice: '',
    quantity: '',
    notes: '',
    images: [] as string[]
  });

  // Load trades only for the current user
  useEffect(() => {
    if (currentUser) {
      const allTrades: Trade[] = JSON.parse(localStorage.getItem('trades_v1') || '[]');
      const userTrades = allTrades.filter(t => t.userEmail === currentUser.email);
      setTrades(userTrades);
    } else {
      setTrades([]);
    }
  }, [currentUser]);

  // Handle outside clicks for profile dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const users: User[] = JSON.parse(localStorage.getItem('trade_trace_users') || '[]');
    const existingUser = users.find(u => u.email === authForm.email);
    
    if (!existingUser) {
      alert("User not found. Please register.");
      return;
    }

    if (existingUser.password !== authForm.password) {
      alert("Wrong password");
      return;
    }
    
    const sessionUser = { ...existingUser };
    // In a real app we'd keep a token, here we keep the password for the "account settings" view as requested
    setCurrentUser(sessionUser);
    localStorage.setItem('trade_trace_session', JSON.stringify(sessionUser));
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const users: User[] = JSON.parse(localStorage.getItem('trade_trace_users') || '[]');
    if (users.find(u => u.email === authForm.email)) {
      alert("User already exists.");
      return;
    }
    
    const newUser: User = {
      email: authForm.email,
      password: authForm.password,
      name: authForm.name,
      createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    localStorage.setItem('trade_trace_users', JSON.stringify(users));
    
    const sessionUser = { ...newUser };
    setCurrentUser(sessionUser);
    localStorage.setItem('trade_trace_session', JSON.stringify(sessionUser));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('trade_trace_session');
    setActiveTab('journal');
    setIsProfileOpen(false);
  };

  const convert = (usdAmount: number) => {
    return usdAmount * CURRENCIES[selectedCurrency].rate;
  };

  const formatValue = (amount: number, minimumFractionDigits = 2) => {
    const converted = convert(amount);
    const symbol = CURRENCIES[selectedCurrency].symbol;
    if (selectedCurrency === 'BTC') return `${symbol}${converted.toFixed(6)}`;
    return `${symbol}${converted.toLocaleString(undefined, { minimumFractionDigits, maximumFractionDigits: minimumFractionDigits })}`;
  };

  const dailySummaries = useMemo(() => {
    const summaries: Record<string, DailySummary> = {};
    trades.forEach(trade => {
      const dateKey = format(parseISO(trade.date), 'yyyy-MM-dd');
      if (!summaries[dateKey]) {
        summaries[dateKey] = { date: dateKey, totalPnl: 0, tradeCount: 0, trades: [] };
      }
      summaries[dateKey].totalPnl += trade.pnl || 0;
      summaries[dateKey].tradeCount += 1;
      summaries[dateKey].trades.push(trade);
    });
    return summaries;
  }, [trades]);

  const stats = useMemo(() => {
    const validTrades = trades.filter(t => !isNaN(t.pnl));
    const total = validTrades.reduce((sum, t) => sum + t.pnl, 0);
    const winners = validTrades.filter(t => t.pnl > 0);
    const losers = validTrades.filter(t => t.pnl < 0);
    const winRate = validTrades.length > 0 ? (winners.length / validTrades.length * 100).toFixed(1) : "0";
    const avgWin = winners.length > 0 ? winners.reduce((sum, t) => sum + t.pnl, 0) / winners.length : 0;
    const avgLoss = losers.length > 0 ? Math.abs(losers.reduce((sum, t) => sum + t.pnl, 0) / losers.length) : 0;
    const totalWinVal = winners.reduce((sum, t) => sum + t.pnl, 0);
    const totalLossVal = Math.abs(losers.reduce((sum, t) => sum + t.pnl, 0));
    const profitFactor = totalLossVal > 0 ? (totalWinVal / totalLossVal).toFixed(2) : (totalWinVal > 0 ? "∞" : "0.00");

    const dist: Record<string, number> = {};
    validTrades.forEach(t => { dist[t.symbol] = (dist[t.symbol] || 0) + 1; });
    const pieData = Object.entries(dist).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 5);

    return { total, winRate, trades: validTrades.length, avgWin, avgLoss, profitFactor, pieData, winners: winners.length, losers: losers.length };
  }, [trades]);

  const chartData = useMemo(() => {
    const sorted = [...trades].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    let cumulative = 0;
    const data = sorted.map(t => {
      cumulative += t.pnl || 0;
      return { date: format(parseISO(t.date), 'MMM dd'), pnl: convert(cumulative) };
    });
    if (data.length === 0) return [{ date: 'Start', pnl: 0 }];
    return data;
  }, [trades, selectedCurrency]);

  const saveTrade = async () => {
    if (!currentUser) return;
    const entry = parseFloat(formData.entryPrice) || 0;
    const exit = parseFloat(formData.exitPrice) || 0;
    const qty = parseFloat(formData.quantity) || 0;
    const pnl = formData.type === TradeType.LONG ? (exit - entry) * qty : (entry - exit) * qty;

    const currentTradeData = editingTradeId ? trades.find(t => t.id === editingTradeId) : null;

    const updatedTrade: Trade = {
      id: editingTradeId || crypto.randomUUID(),
      userEmail: currentUser.email,
      date: currentTradeData?.date || selectedDate.toISOString(),
      symbol: formData.symbol.toUpperCase(),
      type: formData.type,
      entryPrice: entry,
      exitPrice: exit,
      quantity: qty,
      pnl: isNaN(pnl) ? 0 : pnl,
      notes: formData.notes,
      images: formData.images,
      aiAnalysis: currentTradeData?.aiAnalysis
    };

    // AI Analysis check
    const imageChanged = JSON.stringify(formData.images) !== JSON.stringify(currentTradeData?.images || []);
    if (updatedTrade.images.length > 0 && (imageChanged || !updatedTrade.aiAnalysis)) {
      setIsAnalyzing(true);
      try {
        const analysis = await analyzeTradeImage(updatedTrade.images[0], updatedTrade.notes);
        updatedTrade.aiAnalysis = analysis;
      } catch (error) { console.error("AI failed", error); }
      finally { setIsAnalyzing(false); }
    }

    const allTrades: Trade[] = JSON.parse(localStorage.getItem('trades_v1') || '[]');
    let newAllTrades: Trade[];
    if (editingTradeId) {
      newAllTrades = allTrades.map(t => t.id === editingTradeId ? updatedTrade : t);
    } else {
      newAllTrades = [...allTrades, updatedTrade];
    }
    
    localStorage.setItem('trades_v1', JSON.stringify(newAllTrades));
    setTrades(newAllTrades.filter(t => t.userEmail === currentUser.email));
    setIsModalOpen(false);
    setEditingTradeId(null);
  };

  const deleteTrade = (id: string) => {
    if (!currentUser) return;
    if (confirm("Delete this trade record?")) {
      const allTrades: Trade[] = JSON.parse(localStorage.getItem('trades_v1') || '[]');
      const filteredAll = allTrades.filter(t => t.id !== id);
      localStorage.setItem('trades_v1', JSON.stringify(filteredAll));
      setTrades(filteredAll.filter(t => t.userEmail === currentUser.email));
    }
  };

  const openAddModal = () => {
    setEditingTradeId(null);
    setFormData({ symbol: '', type: TradeType.LONG, entryPrice: '', exitPrice: '', quantity: '', notes: '', images: [] });
    setIsModalOpen(true);
  };

  const openEditModal = (trade: Trade) => {
    setEditingTradeId(trade.id);
    setFormData({
      symbol: trade.symbol,
      type: trade.type,
      entryPrice: trade.entryPrice.toString(),
      exitPrice: trade.exitPrice.toString(),
      quantity: trade.quantity.toString(),
      notes: trade.notes,
      images: trade.images
    });
    setIsModalOpen(true);
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050505] p-6">
        <div className="w-full max-w-md bg-[#0a0a0a] border border-white/5 p-10 rounded-[2.5rem] shadow-2xl">
          <div className="text-center mb-10">
            <div className="inline-flex bg-indigo-600/20 p-4 rounded-3xl mb-4 border border-indigo-500/20">
              <BarChart3 size={40} className="text-indigo-400" />
            </div>
            <h1 className="text-3xl font-black text-white mb-2">TradeTrace</h1>
            <p className="text-zinc-500 text-sm font-bold uppercase tracking-widest leading-tight">Master Your Account Cycle</p>
          </div>

          <form onSubmit={isAuthMode === 'login' ? handleLogin : handleRegister} className="space-y-6">
            {isAuthMode === 'register' && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                  <UserIcon size={12} /> Full Name
                </label>
                <input 
                  type="text" required
                  className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                  value={authForm.name} onChange={e => setAuthForm({...authForm, name: e.target.value})}
                />
              </div>
            )}
            <div className="space-y-2">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                <Mail size={12} /> Email Address
              </label>
              <input 
                type="email" required
                className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                value={authForm.email} onChange={e => setAuthForm({...authForm, email: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                <Lock size={12} /> Password
              </label>
              <input 
                type="password" required
                className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                value={authForm.password} onChange={e => setAuthForm({...authForm, password: e.target.value})}
              />
            </div>

            <button type="submit" className="w-full py-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-black text-sm uppercase tracking-widest transition-all shadow-xl shadow-indigo-500/20 active:scale-95 flex items-center justify-center gap-2">
              {isAuthMode === 'login' ? <><Lock size={16} /> Secure Entry</> : <><UserPlus size={16} /> Create Profile</>}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button 
              onClick={() => setIsAuthMode(isAuthMode === 'login' ? 'register' : 'login')}
              className="text-xs font-bold text-zinc-500 hover:text-indigo-400 transition-colors"
            >
              {isAuthMode === 'login' ? "Don't have an account? Register" : "Already have an account? Login"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-zinc-300 pb-20 selection:bg-indigo-500/30">
      {/* Navigation Switch */}
      <aside className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[100] bg-zinc-900/80 backdrop-blur-xl border border-white/10 p-1.5 rounded-2xl flex gap-1 shadow-2xl">
        <button onClick={() => setActiveTab('journal')} className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all ${activeTab === 'journal' ? 'bg-indigo-600 text-white shadow-lg' : 'text-zinc-500 hover:text-white'}`}>
          <LayoutDashboard size={16} /> Journal
        </button>
        <button onClick={() => setActiveTab('portfolio')} className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all ${activeTab === 'portfolio' ? 'bg-indigo-600 text-white shadow-lg' : 'text-zinc-500 hover:text-white'}`}>
          <Wallet size={16} /> Wallet
        </button>
      </aside>

      {/* Top Navigation */}
      <nav className="border-b border-white/5 bg-zinc-900/40 sticky top-0 z-[60] backdrop-blur-2xl">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600/10 p-2 rounded-2xl border border-indigo-500/10">
              <BarChart3 size={24} className="text-indigo-400" />
            </div>
            <div>
              <span className="text-xl font-black text-white tracking-tight">TradeTrace</span>
              <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest leading-none tracking-[0.2em]">Institutional Edge</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden md:block text-right">
              <p className="text-[9px] text-zinc-500 font-black uppercase tracking-widest mb-1">Portfolio Value</p>
              <p className={`text-xl font-black tracking-tight ${stats.total >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {formatValue(stats.total)}
              </p>
            </div>
            
            <div className="h-10 w-px bg-white/5" />

            {/* Profile Dropdown Section */}
            <div className="relative" ref={profileRef}>
              <button 
                onClick={() => setIsProfileOpen(!isProfileOpen)}
                className="flex items-center gap-3 bg-white/5 hover:bg-white/10 border border-white/10 p-1.5 pr-4 rounded-2xl transition-all active:scale-95 group"
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 flex items-center justify-center text-white font-black shadow-lg shadow-indigo-500/20 group-hover:rotate-3 transition-transform">
                  {currentUser.name.charAt(0).toUpperCase()}
                </div>
                <div className="text-left hidden sm:block">
                  <p className="text-xs font-black text-white leading-none mb-1">{currentUser.name}</p>
                  <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">Active Member</p>
                </div>
                <ChevronDown size={14} className={`text-zinc-500 transition-transform duration-300 ${isProfileOpen ? 'rotate-180' : ''}`} />
              </button>

              {isProfileOpen && (
                <div className="absolute top-full right-0 mt-3 w-72 bg-black border border-white/10 rounded-3xl shadow-2xl overflow-hidden z-[110] animate-in fade-in slide-in-from-top-2">
                  <div className="p-6 border-b border-white/5 bg-indigo-600/10">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-14 h-14 rounded-2xl bg-indigo-600 flex items-center justify-center text-2xl font-black text-white shadow-xl shadow-indigo-500/20">
                        {currentUser.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="overflow-hidden">
                        <h4 className="font-black text-white text-lg truncate">{currentUser.name}</h4>
                        <p className="text-xs text-zinc-500 truncate">{currentUser.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 bg-zinc-900/60 px-3 py-2 rounded-xl border border-white/5">
                      <CalendarIcon size={12} className="text-indigo-400" />
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                        Since {currentUser.createdAt ? format(parseISO(currentUser.createdAt), 'MMM yyyy') : 'N/A'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="p-2 space-y-1">
                    <button 
                      onClick={() => { setActiveTab('portfolio'); setIsProfileOpen(false); }}
                      className="w-full text-left px-4 py-3 rounded-xl hover:bg-white/5 transition-all group"
                    >
                      <div className="flex items-center gap-3 mb-0.5">
                        <UserIcon size={16} className="text-zinc-500 group-hover:text-indigo-400 transition-colors" />
                        <span className="text-xs font-black text-zinc-300 group-hover:text-white">View Profile</span>
                      </div>
                      <div className="flex items-center gap-1.5 ml-7 text-[10px] font-bold text-zinc-600 uppercase">
                        <Wallet size={10} /> Wallet: {formatValue(stats.total, 0)}
                      </div>
                    </button>

                    <button className="w-full text-left px-4 py-3 rounded-xl hover:bg-white/5 transition-all group">
                      <div className="flex items-center gap-3 mb-0.5">
                        <Settings size={16} className="text-zinc-500 group-hover:text-indigo-400 transition-colors" />
                        <span className="text-xs font-black text-zinc-300 group-hover:text-white">Account Settings</span>
                      </div>
                      <div className="ml-7 space-y-0.5">
                        <div className="text-[10px] font-bold text-zinc-600 uppercase truncate">ID: {currentUser.email}</div>
                        <div className="flex items-center gap-2">
                           <div className="text-[10px] font-bold text-zinc-600 uppercase flex items-center gap-1">
                              PASS: {showPassword ? currentUser.password : '••••••••'}
                           </div>
                           <button onClick={(e) => { e.stopPropagation(); setShowPassword(!showPassword); }} className="text-zinc-500 hover:text-white">
                              {showPassword ? <EyeOff size={10} /> : <Eye size={10} />}
                           </button>
                        </div>
                      </div>
                    </button>

                    <div className="h-px bg-white/5 my-1 mx-2" />
                    <button 
                      onClick={handleLogout}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-black text-rose-500 hover:bg-rose-500/10 transition-all"
                    >
                      <LogOut size={16} /> Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      {activeTab === 'journal' ? (
        <main className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 space-y-8">
            <section className="bg-zinc-900/40 rounded-[2rem] border border-white/5 overflow-hidden shadow-2xl">
              <div className="flex items-center justify-between px-8 py-6 bg-zinc-900/50 border-b border-white/5">
                <div className="flex items-center gap-4">
                  <h2 className="text-2xl font-black text-white">{format(currentDate, 'MMMM yyyy')}</h2>
                  <div className="flex bg-zinc-800/80 rounded-xl p-1 border border-white/5">
                    <button onClick={() => setCurrentDate(subMonths(currentDate, 1))} className="p-2 hover:bg-zinc-700 rounded-lg transition-colors"><ChevronLeft size={20} /></button>
                    <button onClick={() => setCurrentDate(addMonths(currentDate, 1))} className="p-2 hover:bg-zinc-700 rounded-lg transition-colors"><ChevronRight size={20} /></button>
                  </div>
                </div>
                <button onClick={openAddModal} className="group flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-2xl font-bold transition-all shadow-xl shadow-indigo-500/20 active:scale-95">
                  <Plus size={20} /> New Trade
                </button>
              </div>
              
              <div className="grid grid-cols-7 bg-zinc-900/30 border-b border-white/5">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="py-4 text-center text-[10px] font-black text-zinc-500 uppercase tracking-widest">{day}</div>
                ))}
              </div>
              
              <div className="bg-zinc-900/20">
                {(() => {
                  const monthStart = startOfMonth(currentDate);
                  const monthEnd = endOfMonth(monthStart);
                  const startDate = startOfWeek(monthStart);
                  const endDate = endOfWeek(monthEnd);
                  const rows = [];
                  let days = [];
                  let day = startDate;
                  while (day <= endDate) {
                    for (let i = 0; i < 7; i++) {
                      const formattedDate = format(day, 'yyyy-MM-dd');
                      const summary = dailySummaries[formattedDate];
                      const isCurrentMonth = isSameMonth(day, monthStart);
                      const isSelected = isSameDay(day, selectedDate);
                      const cloneDay = day;
                      days.push(
                        <div key={day.toString()} onClick={() => setSelectedDate(cloneDay)}
                          className={`min-h-[110px] p-2 border-r border-b border-white/5 transition-all cursor-pointer relative group flex flex-col
                            ${!isCurrentMonth ? 'bg-zinc-900/10 text-zinc-700' : 'bg-transparent text-zinc-300'}
                            ${isSelected ? 'bg-indigo-500/10 ring-2 ring-inset ring-indigo-500/30' : 'hover:bg-zinc-800/40'}
                          `}>
                          <div className="flex justify-between items-start mb-1 z-10">
                            <span className={`text-xs font-bold transition-colors ${isSelected ? 'text-indigo-400' : ''}`}>{format(day, 'd')}</span>
                            {summary && (
                              <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-black tracking-tighter ${summary.totalPnl >= 0 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                                {summary.totalPnl >= 0 ? '+' : ''}{summary.totalPnl.toFixed(0)}
                              </span>
                            )}
                          </div>
                          <div className="flex-1 mt-1 overflow-hidden relative">
                            {summary && summary.trades.length > 0 && (
                              <>
                                <div className="flex flex-col gap-0.5 z-10 relative">
                                  {summary.trades.slice(0, 2).map(t => (
                                    <div key={t.id} className="flex items-center gap-1">
                                      <div className={`w-1 h-1 rounded-full ${t.pnl >= 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                                      <span className="text-[8px] font-bold text-zinc-500 truncate">{t.symbol}</span>
                                    </div>
                                  ))}
                                  {summary.trades.length > 2 && <span className="text-[7px] text-zinc-600 font-bold">+{summary.trades.length - 2}</span>}
                                </div>
                                {summary.trades[0].images[0] && <img src={summary.trades[0].images[0]} className="absolute inset-0 w-full h-full object-cover opacity-10 group-hover:opacity-20 transition-opacity rounded" alt="" />}
                              </>
                            )}
                          </div>
                        </div>
                      );
                      day = addDays(day, 1);
                    }
                    rows.push(<div className="grid grid-cols-7" key={day.toString()}>{days}</div>);
                    days = [];
                  }
                  return rows;
                })()}
              </div>
            </section>
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="glass rounded-[2.5rem] border border-white/5 p-8 shadow-2xl sticky top-28">
              <div className="flex items-center gap-4 mb-8">
                <div className="bg-zinc-800 p-3 rounded-2xl border border-white/5 text-indigo-400"><CalendarIcon size={24} /></div>
                <div>
                  <h3 className="text-xl font-black text-white">{format(selectedDate, 'MMM d, yyyy')}</h3>
                  <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Historical Entry</p>
                </div>
              </div>

              <div className="space-y-5 max-h-[calc(100vh-420px)] overflow-y-auto pr-3 custom-scrollbar">
                {dailySummaries[format(selectedDate, 'yyyy-MM-dd')]?.trades.map(trade => (
                  <div key={trade.id} className="bg-zinc-800/30 rounded-3xl border border-white/5 p-5 group hover:bg-zinc-800/50 transition-all">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-xl text-[10px] font-black uppercase ${trade.type === TradeType.LONG ? 'bg-indigo-500/10 text-indigo-400' : 'bg-orange-500/10 text-orange-400'}`}>{trade.type}</div>
                        <span className="text-lg font-black text-white tracking-tight">{trade.symbol}</span>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => openEditModal(trade)} className="text-zinc-600 hover:text-indigo-400 p-1.5"><Pencil size={15} /></button>
                        <button onClick={() => deleteTrade(trade.id)} className="text-zinc-600 hover:text-rose-500 p-1.5"><Trash2 size={16} /></button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 mb-4 text-center">
                      <div className="bg-black/40 p-3 rounded-2xl border border-white/5">
                        <p className="text-[9px] font-black text-zinc-600 uppercase mb-1">Position</p>
                        <p className="text-xs text-zinc-200 font-bold">${trade.entryPrice} → ${trade.exitPrice}</p>
                      </div>
                      <div className="bg-black/40 p-3 rounded-2xl border border-white/5">
                        <p className="text-[9px] font-black text-zinc-600 uppercase mb-1">PnL</p>
                        <p className={`text-sm font-black ${trade.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {trade.pnl >= 0 ? '+' : ''}{trade.pnl.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    {trade.images[0] && (
                      <div className="relative aspect-video rounded-xl overflow-hidden border border-white/5 mb-3 group/img">
                        <img src={trade.images[0]} alt="" className="w-full h-full object-cover grayscale-[0.3] group-hover/img:grayscale-0 transition-all" />
                        <button onClick={() => setPreviewImage(trade.images[0])} className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover/img:opacity-100 transition-opacity"><Maximize2 size={18} className="text-white" /></button>
                      </div>
                    )}
                  </div>
                ))}
                {!dailySummaries[format(selectedDate, 'yyyy-MM-dd')] && (
                  <div className="text-center py-20 border-2 border-dashed border-white/5 rounded-[2rem] text-zinc-700 uppercase font-black text-[10px] tracking-widest">No trades recorded</div>
                )}
              </div>
            </div>
          </div>
        </main>
      ) : (
        <main className="max-w-6xl mx-auto px-6 py-10 space-y-10">
          {/* Wallet Header Card */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
             <div className="md:col-span-2 bg-gradient-to-br from-indigo-600 to-indigo-900 border border-indigo-500/20 rounded-[2.5rem] p-10 flex flex-col justify-between shadow-2xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-8 flex flex-col items-end gap-3 z-20">
                   <div className="relative group/curr">
                      <button className="flex items-center gap-2 bg-white/10 hover:bg-white/20 backdrop-blur-lg px-4 py-2 rounded-2xl border border-white/10 text-xs font-black transition-all text-white">
                        <Coins size={14} className="text-indigo-200" /> {selectedCurrency} <ChevronDown size={12} />
                      </button>
                      <div className="absolute top-full right-0 mt-2 w-48 bg-zinc-900 border border-white/10 rounded-2xl shadow-2xl opacity-0 invisible group-hover/curr:opacity-100 group-hover/curr:visible transition-all z-[110] overflow-hidden">
                         {(Object.keys(CURRENCIES) as CurrencyCode[]).map(code => (
                           <button key={code} onClick={() => setSelectedCurrency(code)} className={`w-full text-left px-5 py-3 text-xs font-bold flex items-center justify-between hover:bg-white/5 transition-colors ${selectedCurrency === code ? 'text-indigo-400 bg-indigo-500/5' : 'text-zinc-400'}`}>
                             <span>{CURRENCIES[code].label}</span><span className="font-black opacity-50">{CURRENCIES[code].symbol}</span>
                           </button>
                         ))}
                      </div>
                   </div>
                   <div className="bg-white/10 backdrop-blur-lg p-4 rounded-3xl border border-white/10 text-indigo-100"><CreditCard size={32} /></div>
                </div>
                
                {/* Visual Accent */}
                <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-white/10 rounded-full blur-[100px] pointer-events-none group-hover:bg-white/20 transition-all duration-700"></div>

                <div className="relative z-10">
                   <p className="text-xs font-black uppercase tracking-[0.3em] text-indigo-200 mb-2">Net Balance ({selectedCurrency})</p>
                   <h1 className={`text-6xl font-black tracking-tighter transition-all duration-500 text-white`}>
                      {formatValue(stats.total)}
                   </h1>
                </div>
                <div className="mt-12 flex gap-10 relative z-10">
                   <div><p className="text-[10px] font-black uppercase text-indigo-200/60 tracking-widest mb-1">Win Rate</p><p className="text-2xl font-black text-white">{stats.winRate}%</p></div>
                   <div><p className="text-[10px] font-black uppercase text-indigo-200/60 tracking-widest mb-1">Executions</p><p className="text-2xl font-black text-white">{stats.trades}</p></div>
                   <div><p className="text-[10px] font-black uppercase text-indigo-200/60 tracking-widest mb-1">Profit Factor</p><p className="text-2xl font-black text-indigo-100">{stats.profitFactor}</p></div>
                </div>
             </div>

             <div className="bg-zinc-900/40 border border-white/5 rounded-[2.5rem] p-8 flex flex-col justify-center shadow-xl">
                <div className="flex items-center gap-2 justify-center mb-8">
                   <PieChartIcon size={16} className="text-indigo-400" />
                   <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-zinc-500">Success Ratio</h3>
                </div>
                <div className="h-48 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={[{ name: 'Wins', value: stats.winners }, { name: 'Losses', value: stats.losers }]} innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                        <Cell fill="#10b981" /><Cell fill="#ef4444" />
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: '#18181b', border: 'none', borderRadius: '12px', fontSize: '10px' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 flex justify-center gap-6 text-[10px] font-black uppercase">
                   <div className="flex items-center gap-2 text-emerald-400"><div className="w-2 h-2 rounded-full bg-emerald-500" /> {stats.winners} Wins</div>
                   <div className="flex items-center gap-2 text-rose-400"><div className="w-2 h-2 rounded-full bg-rose-500" /> {stats.losers} Losses</div>
                </div>
             </div>
          </div>

          <div className="bg-zinc-900/40 border border-white/5 rounded-[3rem] p-10 shadow-2xl">
            <div className="flex items-center justify-between mb-10">
              <div className="flex items-center gap-4">
                <div className="bg-indigo-500/10 p-3 rounded-2xl text-indigo-400"><TrendingUp size={24} /></div>
                <div><h2 className="text-2xl font-black text-white tracking-tight">Equity Curve</h2><p className="text-xs text-zinc-500 font-bold">Your cumulative account growth</p></div>
              </div>
            </div>
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs><linearGradient id="walletCurve" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#6366f1" stopOpacity={0.5}/><stop offset="95%" stopColor="#6366f1" stopOpacity={0}/></linearGradient></defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                  <XAxis dataKey="date" stroke="#52525b" fontSize={11} axisLine={false} tickLine={false} tickMargin={10} />
                  <YAxis stroke="#52525b" fontSize={11} axisLine={false} tickLine={false} tickFormatter={(v) => `${CURRENCIES[selectedCurrency].symbol}${v.toFixed(0)}`} />
                  <Tooltip contentStyle={{ backgroundColor: '#09090b', border: '1px solid #ffffff10', borderRadius: '20px', padding: '15px' }} itemStyle={{ color: '#6366f1', fontWeight: '900' }} />
                  <Area type="monotone" dataKey="pnl" stroke="#6366f1" strokeWidth={5} fill="url(#walletCurve)" animationDuration={1500} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Asset Split & Activity */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
             <div className="bg-zinc-900/40 border border-white/5 rounded-[2.5rem] p-8">
                <div className="flex items-center gap-3 mb-8">
                   <Target className="text-indigo-400" size={20} />
                   <h3 className="text-lg font-black text-white">Top Symbols</h3>
                </div>
                <div className="space-y-4">
                   {stats.pieData.map((item, idx) => (
                      <div key={item.name} className="flex items-center justify-between p-4 bg-black/30 border border-white/5 rounded-2xl">
                         <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-full flex items-center justify-center font-black text-xs" style={{ backgroundColor: `${COLORS[idx % COLORS.length]}20`, color: COLORS[idx % COLORS.length] }}>
                               {item.name.slice(0, 1)}
                            </div>
                            <div>
                               <p className="font-black text-white">{item.name}</p>
                               <p className="text-[10px] font-bold text-zinc-600 uppercase">{item.value} executions</p>
                            </div>
                         </div>
                         <div className="bg-white/5 px-3 py-1 rounded-full"><span className="text-[10px] font-black text-zinc-500 uppercase">Tracked</span></div>
                      </div>
                   ))}
                </div>
             </div>

             <div className="bg-zinc-900/40 border border-white/5 rounded-[2.5rem] p-8">
                <div className="flex items-center gap-3 mb-8">
                   <History className="text-indigo-400" size={20} />
                   <h3 className="text-lg font-black text-white">Recent Activity</h3>
                </div>
                <div className="space-y-4">
                   {[...trades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 5).map(t => (
                      <div key={t.id} className="flex items-center justify-between p-4 bg-black/30 border border-white/5 rounded-2xl hover:bg-white/5 transition-colors cursor-pointer" onClick={() => { setActiveTab('journal'); setSelectedDate(parseISO(t.date)); }}>
                         <div className="flex items-center gap-4">
                            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${t.pnl >= 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                               {t.pnl >= 0 ? <ArrowUpRight size={20} /> : <ArrowDownRight size={20} />}
                            </div>
                            <div>
                               <p className="font-black text-white">{t.symbol}</p>
                               <p className="text-[10px] font-bold text-zinc-600 uppercase">{format(parseISO(t.date), 'MMM d')}</p>
                            </div>
                         </div>
                         <p className={`font-black ${t.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {t.pnl >= 0 ? '+' : ''}{formatValue(t.pnl)}
                         </p>
                      </div>
                   ))}
                </div>
             </div>
          </div>
        </main>
      )}

      {/* Shared Modals */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setIsModalOpen(false)} />
          <div className="relative bg-[#0d0d0d] w-full max-w-2xl rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-8 border-b border-white/5 flex justify-between items-center bg-zinc-900/30">
              <div><h2 className="text-2xl font-black text-white">{editingTradeId ? 'Modify Trade' : 'Record Trade'}</h2><p className="text-xs text-zinc-500 font-bold uppercase tracking-widest">{format(selectedDate, 'MMMM d, yyyy')}</p></div>
              <button onClick={() => setIsModalOpen(false)} className="text-zinc-600 hover:text-white bg-white/5 p-2 rounded-xl transition-colors"><X size={24} /></button>
            </div>
            <div className="p-8 space-y-8 overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Ticker</label>
                  <input type="text" placeholder="E.G. NVDA" className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white font-bold focus:outline-none" value={formData.symbol} onChange={e => setFormData({...formData, symbol: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Type</label>
                  <div className="flex bg-black p-1.5 rounded-2xl border border-white/10">
                    <button className={`flex-1 py-3 rounded-xl text-xs font-black transition-all ${formData.type === TradeType.LONG ? 'bg-indigo-600 text-white shadow-lg' : 'text-zinc-600'}`} onClick={() => setFormData({...formData, type: TradeType.LONG})}>LONG</button>
                    <button className={`flex-1 py-3 rounded-xl text-xs font-black transition-all ${formData.type === TradeType.SHORT ? 'bg-orange-600 text-white shadow-lg' : 'text-zinc-600'}`} onClick={() => setFormData({...formData, type: TradeType.SHORT})}>SHORT</button>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2"><label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Entry</label><input type="number" step="any" className="w-full bg-black border border-white/10 rounded-2xl px-4 py-3 text-white focus:outline-none" value={formData.entryPrice} onChange={e => setFormData({...formData, entryPrice: e.target.value})} /></div>
                <div className="space-y-2"><label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Exit</label><input type="number" step="any" className="w-full bg-black border border-white/10 rounded-2xl px-4 py-3 text-white focus:outline-none" value={formData.exitPrice} onChange={e => setFormData({...formData, exitPrice: e.target.value})} /></div>
                <div className="space-y-2"><label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Qty</label><input type="number" step="any" className="w-full bg-black border border-white/10 rounded-2xl px-4 py-3 text-white focus:outline-none" value={formData.quantity} onChange={e => setFormData({...formData, quantity: e.target.value})} /></div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Notes & Thesis</label>
                <textarea rows={3} placeholder="Technical factors..." className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-white focus:outline-none resize-none" value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Evidence (Screenshots)</label>
                <div className="flex gap-4 flex-wrap">
                  <label className="w-24 h-24 rounded-2xl border-2 border-dashed border-white/10 hover:border-indigo-500/40 flex flex-col items-center justify-center cursor-pointer bg-black text-zinc-700 transition-colors">
                    <ImageIcon size={24} />
                    <span className="text-[8px] mt-1 uppercase font-black">Upload</span>
                    <input type="file" className="hidden" accept="image/*" multiple onChange={(e) => {
                      const files = e.target.files; 
                      if (files) {
                        Array.from(files).forEach((file: File) => { 
                          const reader = new FileReader(); 
                          reader.onloadend = () => {
                            const res = reader.result;
                            if (typeof res === 'string') {
                              setFormData(prev => ({...prev, images: [...prev.images, res]}));
                            }
                          }; 
                          reader.readAsDataURL(file); 
                        });
                      }
                    }} />
                  </label>
                  {formData.images.map((img, idx) => (
                    <div key={idx} className="relative w-24 h-24 group"><img src={img} className="w-full h-full object-cover rounded-2xl border border-white/10" alt="" /><button onClick={() => setFormData(p => ({...p, images: p.images.filter((_, i) => i !== idx)}))} className="absolute -top-2 -right-2 bg-rose-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"><X size={10} /></button></div>
                  ))}
                </div>
              </div>
            </div>
            <div className="p-8 border-t border-white/5 bg-zinc-900/30">
              <button onClick={saveTrade} disabled={isAnalyzing || !formData.symbol} className={`w-full py-5 rounded-2xl font-black text-sm uppercase tracking-widest transition-all shadow-2xl flex items-center justify-center gap-2 ${isAnalyzing ? 'bg-zinc-800' : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-500/20 active:scale-95'}`}>
                {isAnalyzing ? <><BrainCircuit size={18} className="animate-spin-slow" /> Mentalizing...</> : (editingTradeId ? 'Sync Updates' : 'Commit Trade')}
              </button>
            </div>
          </div>
        </div>
      )}

      {previewImage && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/95 p-8" onClick={() => setPreviewImage(null)}>
          <button className="absolute top-8 right-8 text-white/50 hover:text-white transition-colors"><X size={40} /></button>
          <img src={previewImage} className="max-w-full max-h-full object-contain rounded-xl shadow-2xl" alt="" />
        </div>
      )}
    </div>
  );
};

export default App;
