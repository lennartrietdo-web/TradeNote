
export enum TradeType {
  LONG = 'LONG',
  SHORT = 'SHORT'
}

export interface Trade {
  id: string;
  userEmail: string; // Associated with a specific user profile
  date: string; // ISO format
  symbol: string;
  type: TradeType;
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  pnl: number;
  notes: string;
  images: string[]; // base64 strings
  aiAnalysis?: string;
}

export interface User {
  email: string;
  password?: string; // In a real app, this would be hashed and handled by a backend
  name: string;
  createdAt: string;
}

export interface DailySummary {
  date: string;
  totalPnl: number;
  tradeCount: number;
  trades: Trade[];
}
